==========================================================

Thanks for your interest in tqwNet.

Setup is pretty simple, once you have been granted a node
number and HUB connection details, you will be able to
configure your BBS according to the instructions.

Please email me if you have questions
or need any help - ml@erb.pw 

Many thanks to Al and Deon for your help and patience in
helping with the setup of the new network.
- thanks guys :)

==========================================================

This archive contains the following:

tqwnet.txt	- Information about tqwNet & application form
history.txt	- History of changes made to the tqwNet
systems.txt	- List of connected Bulletin Board Systems
news.txt	- Brief news highlights from tqwNet
tqwnet.xxx	- Current nodelist (uncompressed)
tqwnet.zxx	- Current nodelist (compressed .zip format) 
tqwnet.na  	- Message echolist         
tqw_file.na	- File echolist
tqwnet.ans	- tqwNet Ansi Logo for your BBS

==========================================================
