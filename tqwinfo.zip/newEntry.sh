#!/usr/bin/env bash
vim -O systems.txt news.txt history.txt
